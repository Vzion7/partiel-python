#!/usr/bin/env python
# coding: utf-8

# In[1]:


#La suite de fibonacci


# In[2]:


nterms = int(input("Entrez un nombre: "))
 
n1 = 0
n2 = 1
 
print("\n la suite fibonacci est :")
print(n1, ",", n2, end=", ")
 
for i in range(2, nterms):
  suivant = n1 + n2
  print(suivant, end=", ")
 
  n1 = n2
  n2 = suivant


# In[ ]:





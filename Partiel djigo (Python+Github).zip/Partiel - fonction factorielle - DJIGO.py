#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#fonction factorielle


# In[12]:


def factorielle(n):
    if n == 0:
        return 1
    else:
        return n  * factorielle(n-1)


# In[13]:


factorielle(5)


# In[ ]:





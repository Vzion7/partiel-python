#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#Création de fonction comportant des modules de gestions des exceptions


# In[ ]:


#Saisie d'une chaine de caractère dans les arguments de la fonction


# In[36]:


nom = input("Quel est votre nom ? : ")
if nom.isnumeric():
   print("ceci n'est pas un nom :", nom)
else:
   print("merci ")


# In[ ]:


#Saisie un nombre complexe


# In[40]:


complx = complex(input("Entrer un nombre"));
print(complx.real)


# In[ ]:


#Saisie d'un très grand nombre


# In[31]:


print("Entrer un nombre plus petit que 1000000.")
nb = float(input())

if nb > 1000000:
    print("Ce nombre convient.")
else:
    print("Ce nombre est trop petit.")


# In[ ]:


#Saisie d'un très petit nombre


# In[32]:


print("Entrer un nombre plus petit que 1.")
nb = float(input())

if nb < 1:
    print("Ce nombre convient.")
else:
    print("Ce nombre est trop grand.")


# In[ ]:


#Saisie d'un nombre négatif


# In[33]:


print("Entrer un nombre plus petit que 0.")
nb = float(input())

if nb < 0:
    print("Ce nombre convient.")
else:
    print("Ce nombre est trop grand.")


# In[34]:


type('hello world') == str
# output: True

type(10) == str
# output: False


# In[37]:


nom = input("Quel est votre nom ? : ")
if nom.isnumeric():
   print("ceci n'est pas un nom :", nom)
else:
   print("merci ")


# In[ ]:





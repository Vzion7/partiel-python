#!/usr/bin/env python
# coding: utf-8

# In[8]:


from math import sqrt


# In[ ]:


#polynome


# In[26]:


def polynome(x):
    return x**3 - 1.5*x**2 - 6*x + 5


# In[27]:


polynome(5)


# In[ ]:




